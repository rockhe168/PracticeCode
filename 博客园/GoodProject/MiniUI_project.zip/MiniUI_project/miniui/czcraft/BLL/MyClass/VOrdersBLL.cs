﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using czcraft.Model;
using czcraft.DAL;
using System.Data;
namespace czcraft.BLL
{
   public partial class VOrdersBLL
    {

    }
}

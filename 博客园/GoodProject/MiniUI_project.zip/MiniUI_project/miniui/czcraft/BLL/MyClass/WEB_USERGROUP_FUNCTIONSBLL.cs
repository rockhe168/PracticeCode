﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using czcraft.Model;
using czcraft.DAL;
using Newtonsoft.Json;
using System.IO;
namespace czcraft.BLL
{
   public partial class WEB_USERGROUP_FUNCTIONSBLL
    {

    }
}

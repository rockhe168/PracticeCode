



function showDaTu(src){
document.getElementById("datu").src=src;
document.getElementById("thickImg").href ="pro_show.aspx?id="+src;
}
/*
$(window.onload=function(src){
	document.getElementById("datu1").src=src;
	});
	
*/
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using czcraft.Model;
using czcraft.DAL;
namespace czcraft.DAL
{
    public partial class orderproductDAL
    {
 
    }
}
